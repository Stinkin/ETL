# Modelo ETL
Version 0.3.20260822
## Reglas Generales
Estas reglas se aplican a todas las dimensiones, salvo que explicitamente se definan nuevas en la dimension
### Validaciones
Toda dependencia debe existir.
Toda clave referenciada debe existir en su dimensión.
### Manejo de Errores
Salvo que la transformación o regla específica indique algo diferente, si alguna validación falla:
- El registro rechazado no será cargado.
- Registrar el error.
- Informar el registro afectado.
- Procesar proximo registro.
### Precondiciones
Para cada archivo requerido:
- El archivo debe encontrarse disponible.
- La estructura del archivo corresponde a la versión vigente.
- El archivo esta actualizado.
## Origenes de datos - Archivos de Origen

El proceso ETL consume un total de 7 archivos de origen, clasificados según su naturaleza y frecuencia de actualización:

### 1. Bajadas Operativas Semanales (2 Archivos)
Archivos dinámicos de extracción operativa que alimentan las dimensiones construidas, el seguimiento semanal y el consumo de horas.

* **`DTI 2026 - Consolidado_vX.X.XXXX.xlsx`** (`BajadaProyectos`)
  * **Frecuencia:** Semanal.
  * **Uso:** Carga `DimProyecto` y la tabla de hechos `FactSeguimientoProyecto`.
* **`Reporte Kairos XXXXXXXX.xlsx`** (`RegistroHoras` / `RegistroTareas`)
  * **Frecuencia:** Semanal.
  * **Uso:** Carga la tabla de hechos `FactRegistroHoras` y detecta nuevas tareas para `DimTarea`.

### 2. Archivos Estáticos y Gobernados (5 Archivos)
Archivos de soporte, catálogos maestros, mapeos, homologaciones y presupuestos administrados por el negocio.

* **`ETL-Maestro.xlsx`**
  * **Frecuencia:** Semestral / Anual.
  * **Uso:** Contiene las tablas de Dimensiones Maestras, la hoja de mapeo `MapeoDireccionBolsa` y la hoja de asignación presupuestaria `AsignacionBolsa`.
* **`Recursos - Disponibilidad.xlsx`** (`TablaCapacity`)
  * **Frecuencia:** Mensual.
  * **Uso:** Carga la capacidad, estado y costo mensual en `FactSeguimientoRecurso`.
* **`Recursos - Planificacion.xlsx`** (`RegistroPlanificacion`)
  * **Frecuencia:** Mensual.
  * **Uso:** Carga la asignación y planificación futura de horas en `FactAsignacionRecursos`.
* **`Mapeo Requerimiento-Proyecto.xlsx`** (`MapeoRequerimientos`)
  * **Frecuencia:** Semanal.
  * **Uso:** Mapeo explícito entre Requerimientos de Kairos y Proyectos para la carga de `DimRequerimiento`.
* **`Mapeo Tarea-Clasificacion.xlsx`** (`MapeoTareas`)
  * **Frecuencia:** Semanal.
  * **Uso:** Mapeo explícito entre Tareas de planificacion y Categorias para la carga de `DimTarea`.
* **`ETL - Homologacion.xlsx`** 
  * **Frecuencia:** Eventual.
  * **Uso:** Normaliza equivalencias de texto mediante las tablas `HomologacionDireccion`, `HomologacionEquipo` y `HomologacionRecurso`.
## Origenes de datos - Dimensiones Maestras
### DimEquipo
#### Definicion
**Objetivo**
Listado maestro de los equipos de desarrollo
**Grano**
Cada fila representa un equipo de desarrollo.
**Destino**
DimEquipo
#### Origen
**Fuente(s) de datos.**
Maestro de Equipos
**Implementación actual.**
ETL-Maestro.xlsx / Hoja Equipos
#### Referencias
No Aplica
#### Validaciones.
KeyEquipo obligatorio
KeyEquipo único
NombreEquipo obligatorio.
#### Proceso de carga.
Cada registro válido del Maestro Equipos genera exactamente un registro en DimEquipo.
#### Transformaciones.
No Aplica
#### Controles
**Manejo de errores.**
Aplican Reglas Generales
**Precondiciones**
Aplican Reglas Generales
### DimRecursoPerfil
#### Definicion
**Objetivo**
Listado maestro de los perfiles de los recursos
**Grano**
Cada fila representa un perfil de recurso 
**Destino**
DimRecursoPerfil
#### Origen
**Fuente(s) de datos**
Maestro de Perfiles
**Implementación actual**
ETL-Maestro.xlsx / Hoja Perfiles
#### Referencias
No Aplica
#### Validaciones.
KeyRecursoPerfil obligatorio
KeyRecursoPerfil único
NombreRecursoPerfil obligatorio.
#### Proceso de carga.
Cada registro válido del Maestro Perfiles genera exactamente un registro en DimRecursoPerfil
#### Transformaciones.
No Aplica
#### Controles
**Manejo de errores.**
Aplican Reglas Generales
**Precondiciones**
Aplican Reglas Generales
### DimRecursoSkill
#### Definicion
**Objetivo**
Listado maestro de los skills de los recursos
**Grano**
Cada fila representa un skill de recurso 
**Destino**
DimRecursoSkill
#### Origen
**Fuente(s) de datos**
Maestro de Skills
**Implementación actual**
ETL-Maestro.xlsx / Hoja Skills
#### Referencias
No Aplica
#### Validaciones.
KeyRecursoSkill obligatorio
KeyRecursoSkill único
NombreRecursoSkill obligatorio.
#### Proceso de carga.
Cada registro válido del Maestro Skills genera exactamente un registro en DimRecursoSkill
#### Transformaciones.
No Aplica
#### Controles
**Manejo de errores**
Aplican Reglas Generales
**Precondiciones**
Aplican Reglas Generales
### DimRecursoOrigen
#### Definicion
**Objetivo**
Listado maestro de los Origenes de los recursos
**Grano**
Cada fila representa un origen de recurso 
**Destino**
DimRecursoOrigen
#### Origen
**Fuente(s) de datos**
Maestro de Origenes
**Implementación actual**
ETL-Maestro.xlsx / Hoja Origenes
#### Referencias
No Aplica
#### Validaciones.
- KeyRecursoOrigen obligatorio
- KeyRecursoOrigen único
- NombreRecursoOrigen obligatorio.
#### Proceso de carga.
Cada registro válido del Maestro Origenes genera exactamente un registro en DimRecursoOrigen
#### Transformaciones.
No Aplica
#### Controles
**Manejo de errores**
Aplican Reglas Generales
**Precondiciones**
Aplican Reglas Generales
### DimRecursoVinculo
#### Definicion
**Objetivo**
Listado maestro de los Vinculos de los recursos
**Grano**
Cada fila representa un Vinculo de recurso 
**Destino**
DimRecursoVinculo
##### Origen
**Fuente(s) de datos**
Maestro de Vinculos
**Implementación actual**
ETL-Maestro.xlsx / Hoja Vinculos
#### Referencias
No Aplica
#### Validaciones.
- KeyRecursoVinculo obligatorio
- KeyRecursoVinculo único
- NombreRecursoVinculo obligatorio.
#### Proceso de carga.
Cada registro válido del Maestro Vinculos genera exactamente un registro en DimRecursoVinculo
#### Transformaciones.
No Aplica
#### Controles
**Manejo de errores**
Aplican Reglas Generales
**Precondiciones**
Aplican Reglas Generales
### DimRequerimientoCategoria
#### Definicion
**Objetivo**
Listado maestro de las categorias de Requerimientos
**Grano**
Cada fila representa una categoria de Requerimientos
**Destino**
DimRequerimientoCategoria
#### Origen
**Fuente(s) de datos**
Maestro de Categorias
**Implementación actual**
ETL-Maestro.xlsx / Hoja Categorias
#### Referencias
No Aplica
#### Validaciones.
- KeyRequerimientoCategoria obligatorio
- KeyRequerimientoCategoria único
- NombreRequerimientoCategoria obligatorio.
#### Proceso de carga.
Cada registro válido del Maestro Categorias genera exactamente un registro en DimRequerimientoCategoria
#### Transformaciones.
No Aplica
#### Controles
**Manejo de errores**
Aplican Reglas Generales
**Precondiciones**
Aplican Reglas Generales
### DimTareaClasificacion
#### Definicion
**Objetivo**
Listado maestro de las clasificaciones de Tareas
**Grano**
Cada fila representa una clasificacion de Tareas
**Destino**
DimTareaClasificacion
#### Origen
**Fuente(s) de datos**
Maestro de Clasificaciones
**Implementación actual**
ETL-Maestro.xlsx / Hoja Clasificaciones
#### Referencias
No Aplica
#### Validaciones.
- KeyTareaClasificacion obligatorio
- KeyTareaClasificacion único
- NombreTareaClasificacion obligatorio.
#### Proceso de carga.
Cada registro válido del Maestro Clasificaciones genera exactamente un registro en DimTareaClasificacion
#### Transformaciones.
No Aplica
#### Controles
**Manejo de errores**
Aplican Reglas Generales
**Precondiciones**
Aplican Reglas Generales
### DimDireccion
#### Definicion
**Objetivo**
Listado maestro de las Direcciones
**Grano**
Cada fila representa una Direccion
**Destino**
DimDireccion
#### Origen
**Fuente(s) de datos**
Maestro de Direcciones
**Implementación actual**
ETL-Maestro.xlsx / Hoja Direcciones
#### Referencias
No Aplica
#### Validaciones.
- KeyDireccion obligatorio.
- KeyDireccion único.
- SiglaDireccion obligatorio.
- SiglaDireccion único.
- NombreDireccion obligatorio.
#### Proceso de carga.
Cada registro válido del Maestro Direcciones genera exactamente un registro en DimDireccion
#### Transformaciones.
No Aplica
#### Controles
**Manejo de errores**
Aplican Reglas Generales
**Precondiciones**
Aplican Reglas Generales
### DimBolsa
#### Definicion
**Objetivo**
Listado maestro de las Bolsas de Horas de Desarrollo
**Grano**
Cada fila representa una Bolsa de Horas
**Destino**
DimBolsa
#### Origen
**Fuente(s) de datos**
Maestro de Bolsas
**Implementación actual**
ETL-Maestro.xlsx / Hoja Bolsas
#### Referencias
No Aplica
#### Validaciones.
- KeyBolsa obligatorio.
- KeyBolsa único.
- NombreBolsa obligatorio.
- ActivoBolsa obligatorio (0/1)
#### Proceso de carga.
Cada registro válido del Maestro Bolsas genera exactamente un registro en DimBolsa
#### Transformaciones.
No Aplica
#### Controles
**Manejo de errores**
Aplican Reglas Generales
**Precondiciones**
Aplican Reglas Generales
### DimCiclo
#### Definicion
**Objetivo**
Listado maestro de los Ciclos de Desarrollo
**Grano**
Cada fila representa un Ciclo de Desarrollo
**Destino**
DimCiclo
#### Origen
**Fuente(s) de datos**
Maestro de Ciclos
**Implementación actual**
ETL-Maestro.xlsx / Hoja Ciclos
#### Referencias
No Aplica
#### Validaciones.
- KeyCiclo obligatorio.
- KeyCiclo único.
- NombreCiclo obligatorio.
- AñoCiclo obligatorio
- EsVentana obligatorio (0/1)
#### Proceso de carga.
Cada registro válido del Maestro de Ciclos genera exactamente un registro en DimCiclo
#### Transformaciones.
No Aplica
#### Controles
**Manejo de errores**
Aplican Reglas Generales
**Precondiciones**
Aplican Reglas Generales
### DimProyectoEstado
#### Definicion
**Objetivo**
Listado maestro de los Estados de un Desarrollo
**Grano**
Cada fila representa un Estado
**Destino**
DimProyectoEstado
#### Origen
**Fuente(s) de datos**
Maestro de Estados
**Implementación actual**
ETL-Maestro.xlsx / Hoja EstadosProyecto
#### Referencias
No Aplica
#### Validaciones.
- KeyProyectoEstado obligatorio.
- KeyProyectoEstado único.
- NombreProyectoEstado obligatorio.
#### Proceso de carga.
Cada registro válido del Maestro de Estados genera exactamente un registro en DimProyectoEstado
#### Transformaciones.
No Aplica
#### Controles
**Manejo de errores**
Aplican Reglas Generales
**Precondiciones**
Aplican Reglas Generales
### DimProyectoSituacion
#### Definicion
**Objetivo**
Listado maestro de las Situaciones de un Desarrollo
**Grano**
Cada fila representa una Situacion
**Destino**
DimProyectoSituacion
#### Origen
**Fuente(s) de datos**
Maestro de Situaciones
**Implementación actual**
ETL-Maestro.xlsx / Hoja SituacionProyecto
#### Referencias
No Aplica
#### Validaciones.
- KeyProyectoSituacion obligatorio.
- KeyProyectoSituacion único.
- NombreSituacionProyecto obligatorio.
#### Proceso de carga.
Cada registro válido del Maestro de SituacionesProyecto genera exactamente un registro en DimProyectoSituacion
#### Transformaciones.
No Aplica
#### Controles
**Manejo de errores**
Aplican Reglas Generales
**Precondiciones**
Aplican Reglas Generales
## Origenes de datos - Dimensiones Conformadas
### DimRecurso
#### Definicion
**Objetivo**
Listado de todos los recursos que participan en desarrollos
**Grano**.
Cada fila representa un recurso
**Destino**
DimRecurso
#### Origen
**Fuente(s) de datos**
Maestro de Recursos
**Implementación actual**
ETL-Maestro.xlsx / Hoja Recursos
#### Referencias
**Dimensiones Utilizadas**
DimRecursoPerfil
DimRecursoSkill
DimRecursoOrigen
DimEquipo
DimRecursoVinculo
#### Validaciones
- KeyRecurso obligatorio.
- KeyRecurso único.
- NombreRecurso obligatorio.
- KeyEquipo existe en DimEquipo.
- KeyRecursoPerfil existe en DimRecursoPerfil.
- KeyRecursoSkill existe en DimRecursoSkill.
- KeyRecursoOrigen existe en DimRecursoOrigen.
- KeyRecursoVinculo existe en DimRecursoVinculo.
Aplican Reglas Generales.
#### Proceso de carga.
Cada registro valido de Maestro de Recursos genera exactamente un registro en DimRecurso
#### Transformaciones
No Aplica
#### Controles
No Aplica
### DimFecha
#### Definicion
**Objetivo**
Catalogo de todas las Dimensiones temporales usando ISO 8601
**Grano**
Cada registro corresponde a un dia calendario
**Destino**
DimFecha
#### Origen
**Fuente(s) de datos**
No Aplica
**Implementación actual**
Generada automáticamente por el ETL.
NO se hacen busquedas, la construccion de una fecha usando el formato ISO 8601 garantiza la existencia de un registro en DimFecha
#### Referencias
No Aplica
#### Validaciones
- KeyFecha unica
- Fecha corresponde a una fecha calendario valida
#### Proceso de carga
Se genera un registro por cada fecha.
#### Transformaciones
KeyFecha es el valor único de la fecha en formato YYYYMMDD
Fecha es la fecha calendario
Año es el año en formato YYYY
Trimestre es el trimestre segun ISO 8601-2:2019
Mes es el mes en formato MM
NombreMes es el nombre del mes en formato mmmm
Semana es el numero de semana segun ISO 8601
DiaSemana es el dia en formato DD
#### Controles
No Aplica
### DimProyecto
#### Definicion
**Objetivo**
Catalogo de los proyectos
**Grano**
Cada registro representa un proyecto
**Destino**
DimProyecto
#### Origen
**Fuente(s) de datos**
Situacion Semanal - Proyectos
**Implementación actual**
DTI 2026 - Consolidado_vX.X.XXXX.xlsx
#### Referencias
**Homologaciones Utilizadas***
HomologacionDireccion
HomologacionEquipo
**Dimensiones Utilizadas**
DimDireccion
DimEquipo
DimCiclo
#### Validaciones
- KeyProyecto obligatorio.
- KeyProyecto único.
- NombreProyecto obligatorio.
####  Proceso de carga
Cada registro válido del catálogo de proyectos genera exactamente un registro en DimProyecto.
#### Transformaciones
Solo se procesan los registros cuyo campo "Proyecto" tenga un valor distinto de "NO". Los registros con valor "NO" no representan proyectos y son descartados del proceso.
Se almacena el valor de la columna "Cod Proy" en el campo KeyProyecto.
Se almacena el valor de la columna "Nombre de Tarea" en el campo NombreProyecto. (Representa el proyecto en el sistema origen)
Se busca el valor de la columna "Direccion Solicitante" en la tabla HomologacionDireccion y se carga el key en KeyDireccion.
Se busca el valor de la columna "Equipo" en HomologacionEquipo y se carga en TempEquipo
Se busca TempEquipo en DimEquipo y se almacena en KeyEquipo.
Se busca el valor de la columna "Ciclo" en DimCiclo y se carga el key en KeyCiclo.
#### Controles
**Registro Default**
No posee Registro Default propio. Ante errores de resolución de claves externas se utiliza el Registro Default de la dimensión correspondiente.
**Manejo de errores**
Si falla KeyProyecto o NombreProyecto, Aplican Reglas Generales.
Si falla en otro campo, se reemplaza por 0 la key fallida.
### DimTarea
#### Definicion
**Objetivo**
Catalogo de las tareas, con su categoria y proyecto
**Grano**
Cada registro representa una tarea programada
**Destino**
DimTarea
#### Origen
**Fuente(s) de datos**
MapeoTareas
RegistroPlanificacion
**Implementación actual**
MapeoTareas: Mapeo Tarea-Clasificacion.xlsx
RegistroPlanificacion: Recursos - Planificacion.xlsx
#### Referencias
**Dimensiones Utilizadas**
DimTareaClasificacion
#### Validaciones
- KeyTarea obligatorio.
- KeyTarea único.
- NombreTarea obligatorio.
- NombreTarea + KeyProyecto único.
####  Proceso de carga
Cada registro válido de MapeoTareas genera exactamente un registro en DimTarea.
Cada registro unico de RegistroPlanificacion se transforma en un registro, ya sea gobernado o se agrega al final

#### Transformaciones
Primera fase: (Tareas previamente catalogadas)
Sobre MapeoTareas:
Se almacena el valor de la columna "ID" en el campo KeyTarea.
Se almacena el valor de la columna "Tarea" en el campo NombreTarea
Se busca el valor de la columna "Clasificacion" en la tabla DimTareaClasificacion y se almacena el key en KeyTareaClasificacion
Se busca el valor de la columna "Proyecto" en la tabla DimProyecto y se almacena la key en KeyProyecto

Segunda fase: (nuevas tareas sin catalogar)
Las tareas detectadas automáticamente se incorporan con valores por defecto hasta ser clasificadas en el catálogo MapeoTareas mediante el proceso manual correspondiente.
Sobre RegistroPlanificacion:
Se eliminan todas las columnas salvo "Tarea" y "Proyecto"
Se eliminan los registros duplicados, conservando un único registro por Tarea y Proyecto.
Se obtienen TempTarea y TempProyecto
Se busca el valor de TempTarea+TempProyecto en MapeoTareas:
- Si la Tarea ya existe en MapeoTareas, se considera previamente gobernada y no genera modificaciones en DimTarea.
- Si no existe, se agrega un nuevo registro almacenando los valores en los campos:
    Se asigna el siguiente KeyTarea disponible, garantizando unicidad dentro de la dimensión.
    NombreTarea con el valor de la columna "Tarea"
    Se busca el valor de la columna "Proyecto" en la tabla DimProyecto y se almacena la key en KeyProyecto
    KeyTareaClasificacion = 0
#### Controles
**Registro Default**
No posee Registro Default propio. Ante errores de resolución de claves externas se utiliza el Registro Default de la dimensión correspondiente.
**Manejo de errores**
MapeoTareas:
Si falla KeyTarea o NombreTarea, Aplican Reglas Generales.
Si falla en otro campo, se reemplaza por 0 la key fallida.
RegistroPlanificacion:
Aplican Reglas Generales.
### DimRequerimiento
#### Definicion
**Objetivo**
Catalogo de los requerimientos, con su categoria y proyecto de existir
**Grano**
Cada registro representa un requerimiento
**Destino**
DimRequerimiento
#### Origen
**Fuente(s) de datos**
RegistroHoras
MapeoRequerimientos
**Implementación actual**
MapeoRequerimientos: Mapeo Requerimiento-Proyecto.xlsx
RegistroHoras: Reporte Kairos XXXXXXXX.xlsx
#### Referencias
**Dimensiones Utilizadas**
DimRequerimientoCategoria
#### Validaciones
- KeyRequerimiento obligatorio.
- KeyRequerimiento único.
- NombreRequerimiento obligatorio.
- NombreRequerimiento único.
####  Proceso de carga
Cada registro válido de MapeoRequerimientos genera exactamente un registro en DimRequerimiento.
Cada registro de RegistroHoras que no se encuentre en MapeoRequerimientos genera exactamente un registro en DimRequerimiento
#### Transformaciones
Primera fase: (requerimientos previamente catalogados)
Sobre MapeoRequerimientos:
Se almacena el valor de la columna "ID" en el campo KeyRequerimiento.
Se almacena el valor de la columna "Requerimiento" en el campo NombreRequerimiento
Se busca el valor de la columna "Categoria" en la tabla DimRequerimientoCategoria y se almacena el key en KeyRequerimientoCategoria
Se almacena el valor de la columna "ID Proy" en KeyProyecto si Categoria = Proyecto.
Se almacena 0 en KeyProyecto si Categoria ≠ Proyecto

Segunda fase: (nuevos requerimientos sin catalogar)
Los requerimientos detectados automáticamente se incorporan con valores por defecto hasta ser clasificados en el catálogo MapeoRequerimientos mediante el proceso manual correspondiente.
Sobre RegistroHoras:
Se eliminan todas las columnas salvo "Requerimiento"
Se eliminan los registros duplicados de "Requerimiento", conservando un único registro por requerimiento.
Se busca el valor de "Requerimiento" en el campo "Requerimiento" de MapeoRequerimientos:
- Si ya existe en MapeoRequerimientos, se considera previamente gobernado y no genera modificaciones en DimRequerimiento.
- Si no existe, se agrega un nuevo registro almacenando los valores en los campos:
    Se asigna el siguiente KeyRequerimiento disponible, garantizando unicidad dentro de la dimensión.
    NombreRequerimiento con el valor de la columna "Requerimiento"
    KeyRequerimientoCategoria = 0
    KeyProyecto = 0
#### Controles
**Registro Default**
No posee Registro Default propio. Ante errores de resolución de claves externas se utiliza el Registro Default de la dimensión correspondiente.
**Manejo de errores**
MapeoRequerimientos:
Si falla KeyRequerimiento o NombreRequerimiento, Aplican Reglas Generales.
Si falla en otro campo, se reemplaza por 0 la key fallida.
RegistroHoras:
Aplican Reglas Generales.
## Origenes de datos - Tablas de Hechos
### FactSeguimientoProyecto
#### Definicion
**Objetivo**
Estado de situacion de un proyecto en el Snapshot semanal
**Grano**
Cada fila representa la situacion de un proyecto en el Snapshot de esa semana
**Destino**
FactSeguimientoProyecto
#### Origen
**Fuente(s) de datos**
BajadaProyectos
**Implementación actual**.
DTI 2026 - Consolidado_vX.X.XXXX.xlsx
#### Referencias
**Dimensiones utilizadas**
DimFecha
DimProyecto
DimProyectoSituacion
DimProyectoEstado
#### Validaciones.
Aplican Reglas Generales.
#### Proceso de carga.
Cada registro válido de BajadaProyectos genera exactamente un registro en FactSeguimientoProyecto.
#### Transformaciones.
Se obtiene TempFechaGeneracion del nombre del archivo procesado.
Solo se procesan los registros cuyo campo "Proyecto" tenga un valor distinto de "NO". Los registros con valor "NO" no representan proyectos y son descartados del proceso.
Se almacena el valor de la columna "Cod Proy" en el campo KeyProyecto.
Se formatea la fecha de generación a YYYYMMDD y se almacena en FechaSnapshot.
Se formatea la columna "Comienzo_Programado" a YYYYMMDD y se almacena en FechaInicioPlan.
Se formatea la columna "FinProgramo" a YYYYMMDD y se almacena en FechaFinPlan.
Se formatea la columna "Comienzo" a YYYYMMDD y se almacena en FechaInicioReal.
Se formatea la columna "Fin" a YYYYMMDD y se almacena en FechaFinReal.
Se almacena la columna "% trabajo completado" en el campo PorcentajeDeAvance convirtiendolo en un valor entre 0 y 1 con dos decimales
Se obtiene el valor numérico de la columna "trabajo" y se almacena en HorasPlanificadas.
Se almacena la columna "Cant. Reprogramaciones" en el campo CantidadReplanificaciones.

Se determina el valor de KeyProyectoEstado aplicando las siguientes reglas en orden:

Se busca el valor de la columna "Proyecto" en DimProyectoEstado y si se encuentra una coincidencia se carga en TempEstado
Si no:
- Si PorcentajeDeAvance = 0, se carga "Sin Comenzar" en TempEstado
- Si PorcentajeDeAvance = 1, se carga "Terminado" en TempEstado
- Si PorcentajeDeAvance esta entre 0 y 1, se carga "En Proceso" en TempEstado
- En cualquier otro caso, se carga "Sin Estado" en TempEstado

Se busca TempEstado en DimProyectoEstado y se almacena en KeyProyectoEstado

Se determina el valor de KeyProyectoSituacion usando las siguientes reglas en orden:
- Si PorcentajeDeAvance = 0:
- - Si (FechaSnapshot > FechaInicioPLan), se carga "Atrasado" en TempSituacion
- - Si (FechaSnapshot <= FechaInicioPlan), se carga "En Fecha" en TempSituacion.
- Si PorcentajeDeAvance = 1:
- - Si (FechaFinReal <= FechaFinPlan), se carga "En Fecha" en TempSituacion.
- - Si (FechaFinReal > FechaFinPlan), se carga "Atrasado" en TempSituacion.
- Si 0 < PorcentajeDeAvance < 1:
- - Si (FechaSnapshot < FechaInicioPlan), se carga "Adelantado" en TempSituacion.
- - Si (FechaSnapshot > FechaFinPlan), se carga "Atrasado" en TempSituacion.
- - Sino, se carga "En Fecha" en "TempSituacion"
- Se busca el valor de TempSituacion en DimProyectoSituacion y se almacena la KeyProyectoSituacion correspondiente.
- En cualquier otro caso, se almacena 0.
#### Controles
**Manejo de errores**
Aplican Reglas Generales.
**Precondiciones**
Aplican Reglas Generales.
### FactRegistroHoras
#### Definicion
**Objetivo**
Registros de consumo de horas en tareas
**Grano**
Cada registro es la cantidad de horas aplicadas a una tarea dentro de una semana
**Destino**
FactRegistroHoras
#### Origen
**Fuente(s) de datos**
RegistroHoras
**Implementación actual**.
Reporte Kairos XXXXXXXX.xlsx
#### Referenciasrenglo
**Homologaciones utilizadas**
HomologacionRecurso
HomologacionEquipo
**Dependencias**
DimFecha
DimRecurso
DimTarea
#### Validaciones.
Aplican Reglas Generales.
#### Proceso de carga.
Cada combinación única de TempRecurso, TempTarea y TempSemana genera exactamente un registro en FactRegistroHoras, luego de consolidar las horas correspondientes.
#### Transformaciones.
Se lee el valor de "Requerimiento" y se obtiene TempTarea
Se busca la columna "Recurso" en HomologacionRecurso y se obtiene TempRecurso.
Se busca la columna "Equipo" en HomologacionEquipo y se obtiene TempEquipo
Se transforma la columna "Periodo" al primer día de la semana correspondiente, según la convención definida por la arquitectura, y se obtiene el valor en TempSemana.
Se consolida la información agrupando por TempRecurso. TempEquipo, TempTarea y TempSemana, sumando las horas de todos los registros pertenecientes al mismo grupo en HorasConsumidas.
Se busca TempRecurso y TempEquipo en DimRecurso y se almacena KeyRecurso.
Se busca TempTarea en el campo NombreTarea de DimTarea y se almacena el resultado en KeyTarea.

Se busca TempSemana en DimFecha y se almacena el resultado en KeyFecha.
#### Controles
**Manejo de errores**
Aplican Reglas Generales.
**Precondiciones**
Aplican Reglas Generales.
### FactAsignacionRecursos
#### Definicion
**Objetivo**
Una fila representa las horas asignadas a un recurso para trabajar en un proyecto durante una fecha determinada.
**Grano**
Cada registro es la cantidad de horas aplicadas a tareas de un Proyecto por un recurso en una fecha determinada
**Destino**
FactAsignacionRecursos
#### Origen
**Fuente(s) de datos**
RegistroPlanificacion
**Implementación actual**.
Recursos - Planificacion.xlsx
#### Referencias
**Homologaciones utilizadas**
HomologacionRecurso
HomologacionEquipo
**Dimensiones Utilizadas**
DimFecha
DimRecurso
DimTarea
DimProyecto
#### Validaciones.
Aplican Reglas Generales.
#### Proceso de carga.
Cada combinación única de TempRecurso, TempEquipo, KeyTarea, KeyProyecto y KeyFecha genera exactamente un registro en FactAsignacionRecursos
#### Transformaciones.
Se busca la columna "Tarea" de DimTarea y se almacena KeyTarea.
Se busca la columna "Proyecto" en DimProyecto y se almacena en KeyProyecto
Se busca la columna "Responsable" en HomologacionRecurso y se obtiene TempRecurso.
Se busca la columna "Equipo" en HomologacionEquipo y se obtiene TempEquipo

Se transforma la columna "fecha" en formato YYYYMMDD y se almacena en KeyFecha.
Se consolida RegistroPlanificacion agrupando por TempRecurso, TempEquipo, KeyTarea, KeyProyecto y KeyFecha, sumando el valor de "minutos" en TempMinutosTotales
Se busca TempRecurso y TempEquipo en DimRecurso y se almacena KeyRecurso.

Se toma TempMinutosTotales se divide por 60 y se almacena como numero con dos decimales en el campo "HorasAsignadas" 
#### Controles
**Manejo de errores**
Aplican Reglas Generales.
**Precondiciones**
Aplican Reglas Generales.
### FactBolsaDeHoras
#### Definicion
**Objetivo**
Una fila representa la situacion de una bolsa de horas 
FactBolsaDeHoras materializa indicadores derivados para desacoplar el acceso a información sensible y reducir el costo de cálculo de indicadores agregados.
FactBolsaDeHoras es una Tabla de Hechos Consolidada, requiere la existencia y valides de las fuetnes de datos previa su carga.
**Grano**
Cada registro es una bolsa de horas en un año determinado
**Destino**
FactBolsaDeHoras
#### Origen
**Fuente(s) de datos**
AsignacionBolsa
FactRegistroHoras
FactAsignacionRecursos
**Implementación actual**.
ETL-Maestro.xlsx / Hoja AsignacionBolsa
#### Referencias
**Homologaciones utilizadas**
No Aplica
**Dimensiones Utilizadas**
DimProyecto
DimBolsa
DimTarea
DimFecha
**Mapeos utilizados**
MapeoDireccionBolsa
#### Validaciones.
Aplican Reglas Generales.
#### Proceso de carga.
Cada registro válido de AsignacionBolsa genera exactamente un registro en FactBolsaDeHoras
#### Transformaciones.
Se genera un registro por cada registro de AsignacionBolsa.

Se busca el valor de la columna "Bolsa" en DimBolsa y se almacena en KeyBolsa.
Se obtiene el valor de la columna "Año" en formato YYYY y se almacena directamente como entero en AñoBolsa.
Se obtiene el valor numérico de la columna "Horas" y se almacena en HorasAsignadas.

Se obtiene el valor de KeyProyecto vinculando FactRegistroHoras con DimTarea
Se obtiene el valor de TempTareaAño vinculando FactRegistroHoras con DimFecha
Se consolida FactRegistroHoras agrupando por KeyProyecto y TempTareaAño, sumando las TempHorasProyectoAño.
Se obtiene KeyDireccion de cada proyecto desde DimProyecto.  
Se busca KeyDireccion en MapeoDireccionBolsa para obtener KeyBolsa. 
Se consolidan TempHorasProyectoAño agrupando por KeyBolsa y TempTareaAño, haciendo coincidir este último con el AñoBolsa, y se almacena el resultado+0 en el campo HorasConsumidas

Se obtiene el valor de TempPlanificacionAño vinculando FactAsignacionRecursos con DimFecha.
Se consolida FactAsignacionRecursos agrupando por KeyProyecto y TempPlanificacionAño, obteniendo TempHorasProgramadasProyecto.
Se obtiene KeyDireccion de cada proyecto desde DimProyecto.
Se busca KeyDireccion en MapeoDireccionBolsa y se obtiene KeyBolsa.
Se consolidan TempHorasProgramadasProyecto agrupando por KeyBolsa y TempPlanificacionAño, haciendo coincidir este último con el AñoBolsa, y se almacena el resultado+0 en el campo HorasProgramadas

Se almacena en HorasDisponibles el resultado de 0+HorasAsignadas − HorasConsumidas.
Se almacena en HorasRestantes el resultado de 0+HorasAsignadas − HorasConsumidas − HorasProgramadas.

#### Controles
**Manejo de errores**
Aplican Reglas Generales.
**Precondiciones**
Aplican Reglas Generales.
Carga exitosa de FactRegistroHoras y FactAsignacionRecursos de los periodos a evaluar.
### FactSeguimientoRecurso
#### Definicion
**Objetivo**
Registro del estado de un recurso
**Grano**
Cada registro es la situacion de un recurso durante un mes
**Destino**
FactSeguimientoRecurso
#### Origen
**Fuente(s) de datos**
TablaCapacity
**Implementación actual**.
Recursos - Disponibilidad.xlsx
#### Referencias
**Homologaciones utilizadas**
HomologacionRecurso
HomologacionEquipo
**Dimensiones utilizadas**
DimRecurso
DimFecha
#### Validaciones.
Aplican Reglas Generales.
#### Proceso de carga.
Cada registro válido de TablaCapacity genera exactamente un registro en FactSeguimientoRecurso.
#### Transformaciones.
Se busca la columna "Recurso" en HomologacionRecurso y se obtiene TempRecurso.
Se busca la columna "Equipo" en HomologacionEquipo y se obtiene TempEquipo
Se busca TempRecurso y TempEquipo en DimRecurso y se almacena KeyRecurso. (Persona + Equipo = Recurso)
Se obtiene el mes y año de la columnas "mes" y "año" y se calcula el primer dia del mes en en formato YYYYMMDD, se almacena en DimFecha (FechaMes)
Se lee el valor de la columna "Estado" y se almacena en Activo como un valor 0 o 1
Se transforma la columna "Asignacion"a un numero entre 0 y 100, y se almacena en PorcentajeDeAsignacion.
Se almacena la columna "Costo" como numero con dos decimales en CostoPorHora
#### Controles
**Manejo de errores**
Aplican Reglas Generales.
**Precondiciones**
Aplican Reglas Generales.